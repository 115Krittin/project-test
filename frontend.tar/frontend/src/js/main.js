import { createTable } from "./components/schedule.component.js";
import { getSchedule } from "./services/schedule.service.js";
import { createEl } from "./utils/dom.util.js";

const headColumn = ["Code", "Title", "Type", "Section", "Group", "Day", "Time", "Weeks", "Remarks"];

document.addEventListener("DOMContentLoaded", async () => {
    const container = document.querySelector("#schedule-container");
    const errorDialog = document.querySelector("#error-dialog");
    errorDialog.addEventListener("cancel", event => event.preventDefault());
    container.replaceChildren(createTable([], headColumn));

    try {
        const data = await getSchedule();
        container.replaceChildren(createTable(data, headColumn));
        if (data.length === 0) {
            const message = createEl("p", [], [{ key: "testid", value: "empty-message" }]);
            message.textContent = "There is currently no class schedule. Please check back later.";
            container.appendChild(message);
        }
    } catch (error) {
        console.error("Could not load class schedules:", error.name);
        errorDialog.showModal();
    }
});
