import { createEl } from "../utils/dom.util.js";

export function createTable(data = [], headColumn = []) {
    const table = createEl("table", [{ key: "id", value: "schedule-table" }], [{ key: "testid", value: "schedule-table" }]);
    const caption = createEl("caption");
    caption.className = "sr-only";
    caption.textContent = "Program class schedule";
    table.append(caption, createHeadTable(headColumn), createBodyTable(data));
    return table;
}

function createHeadTable(headColumn) {
    const thead = createEl("thead");
    const row = createEl("tr");
    headColumn.forEach(name => {
        const column = createEl("th", [{ key: "scope", value: "col" }]);
        column.textContent = name;
        row.appendChild(column);
    });
    thead.appendChild(row);
    return thead;
}

function createBodyTable(data) {
    const tbody = createEl("tbody");
    const fragment = document.createDocumentFragment();
    data.forEach(item => {
        const row = createEl("tr", [], [{ key: "testid", value: "schedule-row" }]);
        item.forEach(({ column, value }) => {
            const cell = createEl("td", [], [{ key: "testid", value: column }]);
            cell.textContent = value ?? "";
            row.appendChild(cell);
        });
        fragment.appendChild(row);
    });
    // Empty schedules have no body rows; main.js adds the message below the table.
    tbody.appendChild(fragment);
    return tbody;
}
