export function createEl(tagname, attr=[], data=[]) {
    // attr, data = [{key:'', value:''}]
    const tag = document.createElement(tagname)

    attr.length > 0 && attr.forEach(({key, value}) => {tag.setAttribute(key, value)})

    data.length > 0 && data.forEach(({key, value}) => {tag.dataset[key] =  value})
   
    return tag
}

export function getElement(selector){
    return document.querySelector(selector)
}
