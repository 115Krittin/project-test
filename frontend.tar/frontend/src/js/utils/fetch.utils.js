export async function getData(url) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    try {
        const res = await fetch(url, { signal: controller.signal });
        if (res.status !== 200) {
            throw new Error(`Schedule API returned HTTP ${res.status}`);
        }
        return await res.json();
    } finally {
        clearTimeout(timeout);
    }
}
