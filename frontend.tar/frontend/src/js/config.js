const apiPath = window.APP_CONFIG?.API_BASE_URL ?? "./api/v1/";

// Keep API requests on the same origin and under the current team's path.
export const BASE_URL = new URL(apiPath, window.location.href).href.replace(/\/$/, "");
