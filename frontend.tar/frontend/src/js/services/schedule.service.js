import { BASE_URL } from "../config.js";
import { getData } from "../utils/fetch.utils.js";

export async function getSchedule() {
    const schedules = await getData(`${BASE_URL}/schedules`)
    if (!Array.isArray(schedules)) {
        throw new Error("Schedule API must return an array");
    }
    return convertSchedule(schedules)
}

function capitalize(text) {
    const txtSplit = text.split(' ')
    return txtSplit.map(txt=> txt ? txt[0].toUpperCase() + txt.slice(1).toLowerCase() : txt).join(' ')
}

function convertSchedule(data){
    return data.map((item)=>{
        return [
            {column: 'code', value: item.course.code},
            {column: 'title', value: item.course.title},
            {column: 'type', value: item.course.type},
            {column: 'section', value: item.section},
            {column: 'group', value: item.studentGroup ?? ''},
            {column: 'day', value: capitalize(item.dayOfWeek)} ,
            {column: 'time', value:`${item.startTime}-${item.endTime}`} ,
            {column: 'weeks', value :`${item.startWeek}-${item.endWeek}`} ,
            {column: 'remarks', value :item.remarks ?? ''} ,
        ]
    })    
}
