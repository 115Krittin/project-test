// Public browser configuration: resolve the API under the page's directory.
window.APP_CONFIG = { API_BASE_URL: "./api/v1/" };
